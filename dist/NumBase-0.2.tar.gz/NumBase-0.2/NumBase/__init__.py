"""
:author: lemme-hype
:copyright: (c) 2022 lemme-hype

"""
from .main import NumBase
